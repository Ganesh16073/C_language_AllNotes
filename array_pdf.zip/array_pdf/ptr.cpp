#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
//	int a=100,*ptr;
//	ptr=&a;
//	printf("Address of a %d\n",&a);
//	printf("value of a %d\n",a);
//	printf("Address of ptr %d\n",&ptr);
//	printf("value of ptr %d\n",ptr);
//	printf("value of address in ptr %d\n",*ptr);


int 
}