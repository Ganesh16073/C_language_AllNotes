#include<stdio.h>
#include<conio.h>
int main()
{
	int a[10],i,j,temp;
	printf("Enter a array");
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}

	for(i=0;i<10;i++)
	{
		printf(" index :%d -- value :%d\n",i,a[i]);
	}
}